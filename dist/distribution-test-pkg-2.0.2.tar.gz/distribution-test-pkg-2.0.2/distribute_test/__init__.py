# coding=utf-8

namme = "distribute-test-pkg"