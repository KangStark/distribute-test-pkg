# Distribution Test Package

This is a simple test package to test how distribute one's own project. You can use
[Github-flavored Markdown](https://guides.github.com/features/mastering-markdown/)
to write your content."# distribute-test-pkg" 
